﻿namespace Otel
{
    public class Hotel
    {
        public string Name;
        public string Adres;
        public string HotelInfo;
        public int HotelNumb;
        public string Service;
        public Room[] rooms;
        public Hotel(string hotelname)
        {
            Name = hotelname;
            rooms = new Room[20];
            int roomcount = 20;
            for (int i = 0; i < roomcount; i++)
            {
                Types fortype = Types.Double;
                string roominfo = "Otaq Deniz Menzerelidir";
                if (roomcount+i == 25 || roomcount + i == 29 || roomcount + i == 37 || roomcount + i == 32)
                {
                    fortype = Types.Single;
                    roominfo = "Otaq Deniz Menzerelidir";
                }
                else if ((roomcount + i)%2==0)
                {
                    fortype = Types.Double;
                    roominfo = "Otaq Dag Menzerelidir";
                }
                else if (roomcount % 5 == 0)
                {
                    fortype = Types.Triple;
                    roominfo = "Otaq Gol Menzerelidir";

                }
             
                Room room = new Room
                {
                    Price = $"{(roomcount*2)+i}",

                    RoomInfo = roominfo ,
                    RoomNumb = i+1,
                    Tip = fortype
                };
                rooms[i] = room;
            }

        }
    }


}
