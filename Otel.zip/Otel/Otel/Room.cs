﻿namespace Otel
{
    public class Room
    {
        public int RoomNumb;
        public Types Tip;
        public string Price;
        public string RoomInfo;
    }


}
