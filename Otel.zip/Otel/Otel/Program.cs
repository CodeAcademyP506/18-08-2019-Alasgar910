﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Otel
{
    class Program
    {
        static void Main(string[] args)
        {



            Hotel Rixos = new Hotel("Rixos");
            Rixos.HotelInfo = "Hotelimiz Qubada Yerlesir";
            Rixos.Adres = "Quba Sheher Nugedi kendi";
            Rixos.HotelNumb = 1;
            Rixos.Service = "Hotelimiz 7/24 Xidmet Verir";

            Hotel Hilton = new Hotel("Hilton");
            Hilton.HotelInfo = "Hotelimiz Baki Yerlesir";
            Hilton.Adres = "Baki Sheher Fevvareler meydani";
            Hilton.HotelNumb = 2;
            Hilton.Service = "Hotelimiz Yuksek seviyyeli personellerle xidmetinizdedir";

            Hotel ShamaxiPalace = new Hotel("ShamaxiPalace");
            ShamaxiPalace.HotelInfo = "Hotelimiz Shamaxida Yerlesir";
            ShamaxiPalace.Adres = "Shamxi Sheher Alpan kendi";
            ShamaxiPalace.HotelNumb = 3;
            ShamaxiPalace.Service = "Hotelimizde Butun nov istirahet kompleksleri yaradilib";

            Hotel Absheron = new Hotel("Absheron");
            Absheron.HotelInfo = "Hotelimiz Bakida Yerlesir";
            Absheron.Adres = "Baki Sheher Sahil Prospekti 54";
            Absheron.HotelNumb = 4;
            Absheron.Service = "Hotelimiz size xidmet vermek ucun yolunuzu gozleyir.";


            Console.WriteLine("                      <=====Hotellerimizin Adlari=====>");
            Console.WriteLine(Rixos.HotelNumb + " ==> " + Rixos.Name + " Hoteli " + Rixos.Adres + " Unvaninda Yerlesir... "
                + $"Minimum {Rixos.rooms[0].Price}");
            Console.WriteLine($"    ```Qiymete Xidmetler daxildir... Xidmetlerimiz ==> {Rixos.Service}");

            Console.WriteLine("         <==============================================>");
            Console.WriteLine(Hilton.HotelNumb + " ==> " + Hilton.Name + " Hoteli " + Hilton.Adres + " Unvaninda Yerlesir... "
                + $"Minimum {Hilton.rooms[0].Price}   ");
            Console.WriteLine($"    ```Qiymete Xidmetler daxildir... Xidmetlerimiz ==> {Hilton.Service}");


            Console.WriteLine("         <==============================================>");
            Console.WriteLine(ShamaxiPalace.HotelNumb + " ==> " + ShamaxiPalace.Name + " Hoteli " + ShamaxiPalace.Adres + " Unvaninda Yerlesir... "
                + $"Minimum {ShamaxiPalace.rooms[0].Price}   ");
            Console.WriteLine($"    ```Qiymete Xidmetler daxildir... Xidmetlerimiz ==> {ShamaxiPalace.Service}");


            Console.WriteLine("         <==============================================>");
            Console.WriteLine(Absheron.HotelNumb + " ==> " + Absheron.Name + " Hoteli " + Absheron.Adres + " Unvaninda Yerlesir... "
                + $"Minimum {Absheron.rooms[0].Price} ");
            Console.WriteLine($"    ```Qiymete Xidmetler daxildir... Xidmetlerimiz ==> {Absheron.Service}");

            Console.WriteLine("                                   ");

            Console.WriteLine("    ....Istediyiniz Hotelin Nomresini Secin....               ");
            string hotelnum = Console.ReadLine();

            if (hotelnum == "1")
            {
                Console.WriteLine($"<=== Siz```{Rixos.Name}``` Hoteli Sectiniz..Etrafli Melumat Verilir... ===>");
                Console.WriteLine("                                   ");

                foreach (var item in Rixos.rooms)
                {
                    Console.WriteLine($"==> {item.RoomNumb} nomreli otaq {item.Tip} -dir , Qiymeti {item.Price} AZN-dir");
                    Console.WriteLine(" ");
                }

                Console.WriteLine("<====== Otaq Nomresini Sechin =====>");
                Console.WriteLine("    ");
                string roomnumb = Console.ReadLine();
                Console.WriteLine($"{roomnumb} nomreli seciminizden Eminsiniz????  Beli Ucun -1- , Xeyr Uchun -2- Duymesine Klik Edin");
                string confirm = Console.ReadLine();

                if (confirm == "1")
                {
                    Console.WriteLine($"Rixos {Rixos.HotelInfo } ... {Rixos.rooms[int.Parse(roomnumb)-1].RoomInfo} ");
                    Console.WriteLine("Rezerv etmek istediyinizen eminsiniz? Beli Ucun -1- , Xeyr Uchun -2- Duymesine Klik Edin");

                    string rezerv =  Console.ReadLine();
                    if (rezerv == "1")
                    {
                        Console.WriteLine("Rezerv Tamamlandi...Xosh Istirahetler");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Emeliyyat Legv Edildi");
                        Console.ReadKey();

                    }
                }
                else
                {
                    Console.WriteLine("Emeliyyat Legv Edildi");
                }
                Console.ReadKey();

            }
            else if (hotelnum == "2")
            {
                Console.WriteLine($"<=== Siz```{Hilton.Name}``` Hoteli Sectiniz..Etrafli Melumat Verilir... ===>");
                Console.WriteLine("                                   ");
                foreach (var item in Hilton.rooms)
                {
                    Console.WriteLine($"==> {item.RoomNumb} nomreli otaq {item.Tip} -dir , Qiymeti {item.Price} AZN-dir");
                    Console.WriteLine(" ");
                }

                Console.WriteLine("<====== Otaq Nomresini Sechin =====>");
                Console.WriteLine("    ");
                string roomnumb = Console.ReadLine();
                Console.WriteLine($"{roomnumb} nomreli seciminizden Eminsiniz????  Beli Ucun -1- , Xeyr Uchun -2- Duymesine Klik Edin");
                string confirm = Console.ReadLine();

                if (confirm == "1")
                {
                    Console.WriteLine($"Hilton {Hilton.HotelInfo } ... {Hilton.rooms[int.Parse(roomnumb) - 1].RoomInfo} ");
                    Console.WriteLine("Rezerv etmek istediyinizen eminsiniz? Beli Ucun -1- , Xeyr Uchun -2- Duymesine Klik Edin");

                    string rezerv = Console.ReadLine();
                    if (rezerv == "1")
                    {
                        Console.WriteLine("Rezerv Tamamlandi...Xosh Istirahetler");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Emeliyyat Legv Edildi");
                        Console.ReadKey();

                    }
                }
                else
                {
                    Console.WriteLine("Emeliyyat Legv Edildi");
                }
                Console.ReadKey();


            }
            else if (hotelnum == "3")
            {
                Console.WriteLine($"<=== Siz```{ShamaxiPalace.Name}``` Hoteli Sectiniz..Etrafli Melumat Verilir... ===>");
                Console.WriteLine("                                   ");
                foreach (var item in ShamaxiPalace.rooms)
                {
                    Console.WriteLine($"==> {item.RoomNumb} nomreli otaq {item.Tip} -dir , Qiymeti {item.Price} AZN-dir");
                    Console.WriteLine(" ");
                }

                Console.WriteLine("<====== Otaq Nomresini Sechin =====>");
                Console.WriteLine("    ");
                string roomnumb = Console.ReadLine();
                Console.WriteLine($"{roomnumb} nomreli seciminizden Eminsiniz????  Beli Ucun -1- , Xeyr Uchun -2- Duymesine Klik Edin");
                string confirm = Console.ReadLine();

                if (confirm == "1")
                {
                    Console.WriteLine($"ShamaxiPalace {ShamaxiPalace.HotelInfo } ... {ShamaxiPalace.rooms[int.Parse(roomnumb) - 1].RoomInfo} ");
                    Console.WriteLine("Rezerv etmek istediyinizen eminsiniz? Beli Ucun -1- , Xeyr Uchun -2- Duymesine Klik Edin");

                    string rezerv = Console.ReadLine();
                    if (rezerv == "1")
                    {
                        Console.WriteLine("Rezerv Tamamlandi...Xosh Istirahetler");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Emeliyyat Legv Edildi");
                        Console.ReadKey();

                    }
                }
                else
                {
                    Console.WriteLine("Emeliyyat Legv Edildi");
                }
                Console.ReadKey();
            }
            else if (hotelnum == "4")
            {
                Console.WriteLine($"<=== Siz```{Absheron.Name}``` Hoteli Sectiniz..Etrafli Melumat Verilir... ===>");
                Console.WriteLine("                                   ");
                foreach (var item in Absheron.rooms)
                {
                    Console.WriteLine($"==> {item.RoomNumb} nomreli otaq {item.Tip} -dir , Qiymeti {item.Price} AZN-dir");
                    Console.WriteLine(" ");
                }

                Console.WriteLine("<====== Otaq Nomresini Sechin =====>");
                Console.WriteLine("    ");
                string roomnumb = Console.ReadLine();
                Console.WriteLine($"{roomnumb} nomreli seciminizden Eminsiniz????  Beli Ucun -1- , Xeyr Uchun -2- Duymesine Klik Edin");
                string confirm = Console.ReadLine();

                if (confirm == "1")
                {
                    Console.WriteLine($"Absheron {Absheron.HotelInfo } ... {Absheron.rooms[int.Parse(roomnumb) - 1].RoomInfo} ");
                    Console.WriteLine("Rezerv etmek istediyinizen eminsiniz? Beli Ucun -1- , Xeyr Uchun -2- Duymesine Klik Edin");

                    string rezerv = Console.ReadLine();
                    if (rezerv == "1")
                    {
                        Console.WriteLine("Rezerv Tamamlandi...Xosh Istirahetler");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Emeliyyat Legv Edildi");
                        Console.ReadKey();

                    }
                }
                else
                {
                    Console.WriteLine("Emeliyyat Legv Edildi");
                }
                Console.ReadKey();
            }

            

        }
    }


}
