﻿namespace Otel
{
  public enum Types
    {
        Single,
        Double,
        Triple
    }


}
